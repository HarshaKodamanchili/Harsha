import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Signup } from './signup';


@Injectable({
  providedIn: 'root'
})
export class SignupService {

  private basePath = 'http://localhost:8090/rest/student';

  constructor(private http: HttpClient) { }

  

  createSignup(signup: Signup): Observable<any> {
    return this.http.post(`${this.basePath}/save`, signup, {responseType: 'text'});
  }

  getOneSignup(id1: number): Observable<Signup> {
    return this.http.get<Signup>(`${this.basePath}/one/${id1}`);
  }

 
}
