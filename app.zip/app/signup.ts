
export class Signup {
    id1: number;
    firstname: string;
    lastname: string;
    email: string;
    password: string;
    address: string;
   
}