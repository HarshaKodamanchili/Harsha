import { Component, OnInit } from '@angular/core';
import { SignupService } from './../signup.service';
import { Signup } from '../signup';


@Component({
  selector: 'app-root',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  // form backing object
  signup: Signup;
  // message to ui
  message: String;

  // inject service class
  constructor(private service: SignupService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.signup = new Signup();
  }

  // tslint:disable-next-line: typedef
  createSignup() {
    this.service.createSignup(this.signup)
    .subscribe(data => {
      this.message = data; // read message
      this.signup = new Signup(); // clear form
    }, error => {
      console.log(error);
    });
  }

}
