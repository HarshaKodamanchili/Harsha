package in.nareshit.raghu.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Feedback;

public interface IFeedbackService {



	Integer saveFeedback(Feedback s2);

	Optional<Feedback> getOneFeedback(Integer id2);
	List<Feedback> getAllFeedbacks();

	boolean isFeedbackExist(Integer id2);
}